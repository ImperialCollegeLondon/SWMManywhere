Instructions:

Copy the WBT folder and its entire contents to any location on your system. Configure your Whitebox
frontend, whether that is the QGIS or ArcGIS plugin, or the Python package, to point to this WBT
folder location. To access the functionality of WhiteboxTools without the need for a 3rd party
frontend, launch the WhiteboxTools Runner app (whitebox_runner), if it is contained within the WBT 
folder.